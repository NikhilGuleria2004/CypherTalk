const socket = io();

// Elements for the chat interface
const clientsTotal = document.getElementById('clients-total');
const messageContainer = document.getElementById('message-container');
const nameInput = document.getElementById('name-input');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const feedbackElement = document.getElementById('feedback');

// Elements for the login and registration interface
const loginContainer = document.getElementById('login-container');
const chatContainer = document.getElementById('chat-container');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const loginError = document.getElementById('login-error');
const registerError = document.getElementById('register-error');

let typingTimeout;

// Login form submission
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    const res = await fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    if (res.ok) {
        loginContainer.style.display = 'none';
        chatContainer.style.display = 'block';
        nameInput.value = username;
        socket.emit('login', username);
    } else {
        loginError.textContent = await res.text();
    }
});

// Registration form submission
registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;

    const res = await fetch('/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    if (res.ok) {
        registerError.textContent = 'Registration successful. Please log in.';
    } else {
        registerError.textContent = await res.text();
    }
});

// Handle message form submission
messageForm.addEventListener('submit', (e) => {
    e.preventDefault();
    sendMessage();
});

// Handle incoming chat messages
socket.on('chat-message', (data) => {
    addMessageToUI(false, data);
});

// Update the total number of logged-in clients
socket.on('clients-total', (data) => {
    clientsTotal.innerText = `Total Clients: ${data}`;
});

// Handle feedback messages (e.g., "User is typing...")
socket.on('feedback', (data) => {
    feedbackElement.innerText = data.feedback;
    scrollToBottom(); // Ensure feedback is visible at the bottom
});

// Send a message to the server
function sendMessage() {
    if (messageInput.value === '') return;

    const now = new Date();
    const data = {
        name: nameInput.value,
        message: messageInput.value,
        dateTime: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    socket.emit('message', data);
    addMessageToUI(true, data);
    messageInput.value = '';
    clearFeedback(); // Clear feedback when a message is sent
}

// Add a message to the UI
function addMessageToUI(isOwnMessage, data) {
    const element = `
        <li class="${isOwnMessage ? "message-right" : "message-left"}">
            <p class="message">
                ${data.message}
                <span class="meta">
                    <span>${data.name}</span>
                    <span class="timestamp">${data.dateTime}</span>
                </span>
            </p>
        </li>
    `;
    messageContainer.innerHTML += element;
    scrollToBottom();
}

// Scroll to the bottom of the message container
function scrollToBottom() {
    messageContainer.scrollTo(0, messageContainer.scrollHeight);
}

// Clear the feedback message
function clearFeedback() {
    socket.emit('feedback', { feedback: '' });
    feedbackElement.innerText = ''; // Clear the feedback text
}

// Emit feedback when typing
messageInput.addEventListener('focus', () => {
    socket.emit('feedback', {
        feedback: `${nameInput.value} is typing a message`,
    });
    clearTimeout(typingTimeout);
});

messageInput.addEventListener('keypress', () => {
    socket.emit('feedback', {
        feedback: `${nameInput.value} is typing a message`,
    });

    clearTimeout(typingTimeout);

    typingTimeout = setTimeout(clearFeedback, 1500);
});

messageInput.addEventListener('blur', () => {
    clearFeedback();
});
