const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = 3000;
const server = app.listen(PORT, () => console.log(`Chat Server is on port ${PORT}`));
const io = require('socket.io')(server);

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const DB_FILE = path.join(__dirname, 'DB.json');

let loggedInUsers = new Set();

const readUserData = () => {
    if (!fs.existsSync(DB_FILE)) {
        return [];
    }
    const data = fs.readFileSync(DB_FILE);
    return JSON.parse(data);
};

const writeUserData = (data) => {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
};

// Handle registration
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    let users = readUserData();

    if (users.some(user => user.username === username)) {
        return res.status(400).send('User already exists');
    }

    users.push({ username, password });
    writeUserData(users);
    res.send('Registration successful');
});

// Handle login
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    let users = readUserData();

    const user = users.find(user => user.username === username && user.password === password);
    if (user) {
        res.send('Login successful');
    } else {
        res.status(400).send('Invalid credentials');
    }
});

io.on('connection', (socket) => {
    console.log('clients connected:', socket.id);

    // Send the current number of logged-in users
    io.emit('clients-total', loggedInUsers.size);

    socket.on('login', (username) => {
        console.log(`${username} has logged in.`);
        socket.username = username;  // Associate the username with the socket
        loggedInUsers.add(username);
        io.emit('clients-total', loggedInUsers.size);
    });

    socket.on('logout', () => {
        if (socket.username) {
            loggedInUsers.delete(socket.username);
            io.emit('clients-total', loggedInUsers.size);
        }
    });

    socket.on('disconnect', () => {
        console.log('Socket Disconnected', socket.id);
        if (socket.username) {
            loggedInUsers.delete(socket.username);
            io.emit('clients-total', loggedInUsers.size);
        }
    });

    socket.on('message', (data) => {
        console.log(data);
        socket.broadcast.emit('chat-message', data);
    });

    socket.on('feedback', (data) => {
        socket.broadcast.emit('feedback', data);
    });
});
